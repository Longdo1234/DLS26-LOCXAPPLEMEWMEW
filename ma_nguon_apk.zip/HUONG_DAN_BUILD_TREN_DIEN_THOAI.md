# Build APK ngay trên điện thoại (không cần máy tính)

Dùng GitHub build giúp. Mất khoảng 10 phút lần đầu, các lần sau chỉ vài bấm.

> ⚠ Tạo repo ở chế độ **Private**. Dự án chứa keystore ký APK và mật khẩu; để Public thì ai cũng ký được app giả danh bạn.

## Bước 1. Tạo repo
1. Mở trình duyệt trên điện thoại, vào **github.com**, đăng nhập (chưa có thì đăng ký, miễn phí).
2. Dấu **+** (góc phải trên) → **New repository** → đặt tên bất kỳ (vd `dls-auto`) → chọn **Private** → **Create repository**.
3. Nếu giao diện hiện thiếu nút, bật **"Trang web cho máy tính" (Desktop site)** trong menu trình duyệt.

## Bước 2. Tải mã nguồn lên (1 file duy nhất)
1. Trong repo: **Add file → Upload files**.
2. Chọn file **`ma_nguon_apk.zip`** (không giải nén) → đợi tải xong → **Commit changes**.

## Bước 3. Thêm file build
1. **Add file → Create new file**.
2. Ô tên file gõ đúng: `.github/workflows/build-apk.yml` (gõ dấu `/` thì GitHub tự tạo thư mục).
3. Dán toàn bộ nội dung file `build-apk.yml` (mình gửi kèm) vào ô nội dung → **Commit changes**.

## Bước 4. Chờ build
1. Mở tab **Actions** → chọn lần chạy **Build APK** đang chạy (vòng tròn vàng).
2. Đợi khoảng 3–6 phút đến khi có dấu ✓ xanh. Nếu lỗi đỏ ✗, chụp màn hình dòng đỏ gửi mình.
   (Muốn build lại: Actions → Build APK → **Run workflow**.)

## Bước 5. Tải và cài APK
1. Trang chính của repo → mục **Releases** (cột phải hoặc dưới phần mô tả) → bản mới nhất `DLS Auto APK #1`.
2. Chạm vào **`DLS_Auto_AppleMewMew.apk`** để tải → mở file → **Cài đặt**.
3. Android hỏi quyền "cài ứng dụng không rõ nguồn" → **Cho phép** cho trình duyệt/Files. Nếu Play Protect cảnh báo → **Vẫn cài đặt**.
4. APK ký bằng keystore cũ nên cài **đè lên** bản cũ được, không mất cấu hình.

## Kiểm tra bản build
- Trong **Actions → lần chạy → Artifacts** tải `DLS_Auto_AppleMewMew` (file zip) để xem `SELF_TEST_RESULT.txt`: phải là `SELF-TEST: PASS`.
- Nếu là `FAIL`, APK vẫn dùng được nhưng hãy gửi mình `self-test.log`.
