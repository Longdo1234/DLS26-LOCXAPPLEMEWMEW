#!/usr/bin/env bash
# Build DLS Auto (Apple Mew Mew) -> signed, zipaligned APK on Linux / macOS / GitHub Actions.
# Tuong duong build-apk.ps1 (Windows). Chay:  bash build-apk.sh
# Bien moi truong tuy chon: JAVA_HOME (JDK 17+), ANDROID_HOME hoac ANDROID_SDK_ROOT, KS_PASS, STRICT_TEST=1
set -euo pipefail

PROJ="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_APK="$PROJ/DLS_Auto_AppleMewMew.apk"
BUILD="$PROJ/build"
KS="$PROJ/keystore/applemewmew.jks"
KS_ALIAS="applemewmew"
KS_PASS="${KS_PASS:-AppleMewMew2026!}"

die() { echo "LOI: $*" >&2; exit 1; }
command -v zip >/dev/null 2>&1 || die "Can lenh 'zip' (apt-get install zip)"

# ---------------- JDK 17+ ----------------
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/javac" ]; then
  JBIN="$JAVA_HOME/bin"
elif command -v javac >/dev/null 2>&1; then
  JBIN="$(dirname "$(readlink -f "$(command -v javac)")")"
else
  die "Khong tim thay JDK 17+ (javac). Cai JDK 17 hoac dat JAVA_HOME."
fi
JMAJOR="$("$JBIN/javac" -version 2>&1 | sed -E 's/^javac ([0-9]+).*/\1/')"
[ "$JMAJOR" -ge 17 ] 2>/dev/null || die "Can JDK 17+, dang co javac '$JMAJOR'"

# ---------------- Android SDK ----------------
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then
  for c in "$HOME/Android/Sdk" "$HOME/Library/Android/sdk" /usr/local/lib/android/sdk /opt/android-sdk; do
    if [ -d "$c/platforms" ]; then SDK="$c"; break; fi
  done
fi
[ -n "$SDK" ] && [ -d "$SDK" ] || die "Khong tim thay Android SDK. Dat ANDROID_HOME."

pick_platform() {   # highest android-N (N >= 34) that contains android.jar
  local best="" d n
  for d in "$SDK"/platforms/android-*; do
    [ -f "$d/android.jar" ] || continue
    n="${d##*/android-}"
    case "$n" in ''|*[!0-9]*) continue ;; esac
    [ "$n" -ge 34 ] || continue
    if [ -z "$best" ] || [ "$n" -gt "${best##*/android-}" ]; then best="$d"; fi
  done
  echo "$best"
}
pick_buildtools() { # newest build-tools that has aapt2 + lib/d8.jar
  local best="" d v
  for d in "$SDK"/build-tools/*; do
    [ -f "$d/aapt2" ] && [ -f "$d/lib/d8.jar" ] || continue
    v="${d##*/}"
    case "$v" in *[!0-9.]*) continue ;; esac
    if [ -z "$best" ] || [ "$(printf '%s\n%s\n' "${best##*/}" "$v" | sort -V | tail -1)" = "$v" ]; then best="$d"; fi
  done
  echo "$best"
}

PLAT="$(pick_platform)"; BT="$(pick_buildtools)"
if [ -z "$PLAT" ] || [ -z "$BT" ]; then
  echo "Thieu platform >= 34 hoac build-tools: thu cai bang sdkmanager..."
  SM="$SDK/cmdline-tools/latest/bin/sdkmanager"
  [ -x "$SM" ] || SM="$(command -v sdkmanager || true)"
  [ -n "$SM" ] || die "Khong co platform/build-tools va khong co sdkmanager"
  yes | "$SM" --sdk_root="$SDK" --licenses >/dev/null 2>&1 || true
  "$SM" --sdk_root="$SDK" "platforms;android-34" "build-tools;34.0.0"
  PLAT="$(pick_platform)"; BT="$(pick_buildtools)"
fi
[ -n "$PLAT" ] || die "Khong tim thay Android platform >= 34 (android.jar)"
[ -n "$BT" ] || die "Khong tim thay build-tools (aapt2, lib/d8.jar)"

ANDROID_JAR="$PLAT/android.jar"
AAPT2="$BT/aapt2"; ZIPALIGN="$BT/zipalign"; D8_JAR="$BT/lib/d8.jar"; APKSIGNER_JAR="$BT/lib/apksigner.jar"
JAVA="$JBIN/java"; JAVAC="$JBIN/javac"; KEYTOOL="$JBIN/keytool"
[ -f "$KS" ] || die "Thieu keystore: $KS"

echo "Project : $PROJ"
echo "JDK     : $JBIN (javac $JMAJOR)"
echo "Platform: ${PLAT##*/}   Build-tools: ${BT##*/}"

rm -rf "$BUILD"
mkdir -p "$BUILD/res_flat" "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" "$BUILD/test_classes"

echo "[1/6] Compiling Android resources with aapt2..."
"$AAPT2" compile --dir "$PROJ/res" -o "$BUILD/res_flat/res.zip"
"$AAPT2" link -o "$BUILD/unaligned.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$PROJ/AndroidManifest.xml" \
  -A "$PROJ/assets" \
  --java "$BUILD/gen" \
  "$BUILD/res_flat/res.zip"

echo "[2/6] Compiling Java 17 source files..."
find "$BUILD/gen" "$PROJ/src" -name '*.java' > "$BUILD/sources.txt"
"$JAVAC" --release 17 -encoding UTF-8 -classpath "$ANDROID_JAR" -d "$BUILD/classes" @"$BUILD/sources.txt"

echo "[3/6] Converting bytecode to DEX (d8 --min-api 26)..."
find "$BUILD/classes" -name '*.class' > "$BUILD/classes.txt"
"$JAVA" -cp "$D8_JAR" com.android.tools.r8.D8 --min-api 26 --lib "$ANDROID_JAR" --output "$BUILD/dex" @"$BUILD/classes.txt"
[ -f "$BUILD/dex/classes.dex" ] || die "d8 khong tao ra classes.dex"

echo "[4/6] Packaging classes.dex + zipalign..."
( cd "$BUILD/dex" && zip -q -j "$BUILD/unaligned.apk" classes.dex )
"$ZIPALIGN" -f -p 4 "$BUILD/unaligned.apk" "$BUILD/aligned.apk"

echo "[5/6] Signing APK (V1 + V2 + V3) with Apple Mew Mew release keystore..."
"$JAVA" -jar "$APKSIGNER_JAR" sign \
  --ks "$KS" --ks-key-alias "$KS_ALIAS" \
  --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$OUT_APK" "$BUILD/aligned.apk"
"$JAVA" -jar "$APKSIGNER_JAR" verify -v --print-certs "$OUT_APK"

echo "[6/6] Running JVM Anti-Crack + screen-ratio + Tactical AI self-test..."
"$KEYTOOL" -exportcert -keystore "$KS" -alias "$KS_ALIAS" -storepass "$KS_PASS" -file "$BUILD/cert.der" >/dev/null
TEST_LOG="$PROJ/self-test.log"
set +e
"$JAVAC" --release 17 -encoding UTF-8 -classpath "$BUILD/classes:$ANDROID_JAR" -d "$BUILD/test_classes" "$PROJ/test/ApkEngineSelfTest.java" > "$TEST_LOG" 2>&1
TEST_RC=$?
if [ "$TEST_RC" -eq 0 ]; then
  "$JAVA" -ea -classpath "$BUILD/test_classes:$BUILD/classes:$ANDROID_JAR" ApkEngineSelfTest "$BUILD/cert.der" "$PROJ" >> "$TEST_LOG" 2>&1
  TEST_RC=$?
fi
set -e
cat "$TEST_LOG"
if [ "$TEST_RC" -eq 0 ]; then
  echo "SELF-TEST: PASS" > "$PROJ/SELF_TEST_RESULT.txt"
else
  echo "SELF-TEST: FAIL (ma $TEST_RC) - xem self-test.log" > "$PROJ/SELF_TEST_RESULT.txt"
  echo "CANH BAO: self-test KHONG dat. APK van duoc tao ra nhung hay gui self-test.log cho nguoi phat trien." >&2
  [ "${STRICT_TEST:-0}" = "1" ] && die "Self-test that bai (STRICT_TEST=1)"
fi

SIZE_KB=$(( $(wc -c < "$OUT_APK") / 1024 ))
echo "============================================================="
echo "BUILD APK THANH CONG (${SIZE_KB} KB): $OUT_APK"
cat "$PROJ/SELF_TEST_RESULT.txt"
echo "============================================================="
